const { test, expect } = require('@playwright/test')

test('About me page title check test', async ({ page }) => {

    await page.goto('https://coral-merla-48.tiiny.site/about_me/index.html')
    await expect(page).toHaveTitle('About me')
})