const { test, expect } = require('@playwright/test')

test('Contact me page title check test', async ({ page }) => {

    await page.goto('https://coral-merla-48.tiiny.site/contact_me/index.html')
    await expect(page).toHaveTitle('Contact me')
})