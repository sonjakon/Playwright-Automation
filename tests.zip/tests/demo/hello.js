exports.hello = function f1() {
    return 'hello'
}

exports.helloworld = function f2() {
    return 'hello world'
}