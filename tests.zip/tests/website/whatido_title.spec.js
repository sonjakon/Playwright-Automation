const { test, expect } = require('@playwright/test')

test('What I do page title check test', async ({ page }) => {

    await page.goto('https://coral-merla-48.tiiny.site/what_i_do/index.html')
    await expect(page).toHaveTitle('What I do')
})