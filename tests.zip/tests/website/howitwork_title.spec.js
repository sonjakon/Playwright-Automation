const { test, expect } = require('@playwright/test')

test('How It Work page title check test', async ({ page }) => {

    await page.goto('https://coral-merla-48.tiiny.site/how_it_work/index.html')
    await expect(page).toHaveTitle('How It Work')
})