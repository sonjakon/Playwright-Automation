const { test, expect } = require('@playwright/test')

test('Homepage title check test', async ({ page }) => {

    await page.goto('https://coral-merla-48.tiiny.site/')
    await expect(page).toHaveTitle('My website')
})